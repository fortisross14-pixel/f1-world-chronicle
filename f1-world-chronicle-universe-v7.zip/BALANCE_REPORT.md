# F1 World Chronicle v1.7 balance report

This report uses the real race, development, driver-market and career systems. Each fixed seed was simulated for twelve consecutive F1 seasons (36 seasons total). Historical UI collections were trimmed between seasons only to make the test faster; driver careers, teams, cars, facilities, markets and race logic were left active.

| Seed | Top winner <6 | Top winner 6–7 | Top winner 8–10 | Top winner >10 | Unique champions | Most titles by one driver |
|---:|---:|---:|---:|---:|---:|---:|
| 17 | 0 | 4 | 6 | 2 | 8 | 3 |
| 2026 | 0 | 3 | 6 | 3 | 7 | 4 |
| 20260731 | 1 | 1 | 8 | 2 | 8 | 3 |
| **Total / range** | **1** | **8** | **20** | **7** | **6–8 per run** | **3–4 per run** |

## Interpretation

- 20 of 36 seasons finished with the leading winner on 8–10 victories.
- 8 seasons were open years with the leading winner on 6–7 victories.
- 7 seasons produced a dominant 11+ win campaign.
- Only one season was exceptionally open, with no driver above five wins.
- Each twelve-year era produced 6–8 different champions.
- The most successful driver in each era won 3–4 championships.
- Active Generational drivers never exceeded two. Across the three runs, one was the most common state; some seasons had none and some had a two-career overlap.

These are balance targets rather than hard caps. An exceptional driver, car, circuit match and development cycle can still create a historic season, while weather, reliability, grid position, one-lap versus race skill and team execution can create a close championship.

Run a fixed seed with:

```bash
npm run balance-12 -- 20260731
```

Run all three reference seeds with:

```bash
npm run balance-12
```
